import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import psycopg2


# =====================
# БАЗА ДАННЫХ
# =====================

def get_connection():

    return psycopg2.connect(
        host="localhost",
        port="5432",
        database="shoes_db",
        user="postgres",
        password="12345"
    )


# =====================
# АВТОРИЗАЦИЯ
# =====================

def login():

    login_text = login_entry.get()
    password_text = password_entry.get()

    if login_text == "" or password_text == "":

        messagebox.showerror(
            "Ошибка",
            "Введите логин и пароль"
        )
        return

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT *
        FROM "User"
        WHERE "Логин"=%s
        AND "Пароль"=%s
    """, (
        login_text,
        password_text
    ))

    user = cur.fetchone()

    cur.close()
    conn.close()

    if user is None:

        messagebox.showerror(
            "Ошибка",
            "Неверный логин или пароль"
        )

        return

    open_products(user)


def guest_login():
    open_products(None)


# =====================
# СПИСОК ТОВАРОВ
# =====================

def open_products(user):

    login_frame.pack_forget()

    products_frame.pack(
        fill="both",
        expand=True
    )

    if user:

        user_label.config(
            text=f"{user[1]} ({user[0]})"
        )

    else:

        user_label.config(
            text="Гость"
        )

    load_products()


def load_products():

    for row in tree.get_children():
        tree.delete(row)

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT *
        FROM "Tovar"
    """)

    products = cur.fetchall()

    cur.close()
    conn.close()

    search_text = search_var.get().lower()

    for product in products:

        text = " ".join(
            map(str, product)
        ).lower()

        if search_text not in text:
            continue

        tree.insert(
            "",
            "end",
            values=(
                product[0],
                product[1],
                product[3],
                product[8],
                product[7]
            )
        )


def logout():

    products_frame.pack_forget()

    login_frame.pack(
        fill="both",
        expand=True
    )


# =====================
# ОКНО
# =====================

root = tk.Tk()

root.title("Магазин обуви")
root.geometry("1000x700")

try:
    root.iconbitmap("Icon.ico")
except:
    pass


# =====================
# АВТОРИЗАЦИЯ
# =====================

login_frame = tk.Frame(
    root,
    bg="white"
)

login_frame.pack(
    fill="both",
    expand=True
)

title = tk.Label(
    login_frame,
    text="Авторизация",
    font=("Times New Roman", 20, "bold"),
    bg="white"
)

title.pack(pady=30)

tk.Label(
    login_frame,
    text="Логин",
    bg="white"
).pack()

login_entry = tk.Entry(
    login_frame,
    width=30
)

login_entry.pack(
    pady=5
)

tk.Label(
    login_frame,
    text="Пароль",
    bg="white"
).pack()

password_entry = tk.Entry(
    login_frame,
    width=30,
    show="*"
)

password_entry.pack(
    pady=5
)

tk.Button(
    login_frame,
    text="Войти",
    bg="#00FA9A",
    width=20,
    command=login
).pack(
    pady=10
)

tk.Button(
    login_frame,
    text="Войти как гость",
    bg="#7FFF00",
    width=20,
    command=guest_login
).pack()


# =====================
# ТОВАРЫ
# =====================

products_frame = tk.Frame(
    root,
    bg="white"
)

top_frame = tk.Frame(
    products_frame,
    bg="#7FFF00"
)

top_frame.pack(
    fill="x"
)

user_label = tk.Label(
    top_frame,
    text="",
    bg="#7FFF00",
    font=("Times New Roman", 12, "bold")
)

user_label.pack(
    side="right",
    padx=20,
    pady=10
)

logout_button = tk.Button(
    top_frame,
    text="Выход",
    bg="#00FA9A",
    command=logout
)

logout_button.pack(
    side="left",
    padx=10,
    pady=10
)

search_frame = tk.Frame(
    products_frame,
    bg="white"
)

search_frame.pack(
    fill="x",
    pady=10
)

tk.Label(
    search_frame,
    text="Поиск:",
    bg="white"
).pack(
    side="left",
    padx=10
)

search_var = tk.StringVar()

search_var.trace(
    "w",
    lambda *args: load_products()
)

search_entry = tk.Entry(
    search_frame,
    textvariable=search_var,
    width=40
)

search_entry.pack(
    side="left"
)

tree = ttk.Treeview(
    products_frame,
    columns=(
        "article",
        "name",
        "price",
        "stock",
        "discount"
    ),
    show="headings"
)

tree.heading(
    "article",
    text="Артикул"
)

tree.heading(
    "name",
    text="Наименование"
)

tree.heading(
    "price",
    text="Цена"
)

tree.heading(
    "stock",
    text="Остаток"
)

tree.heading(
    "discount",
    text="Скидка %"
)

tree.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=10
)

root.mainloop()