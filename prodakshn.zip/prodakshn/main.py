from tkinter import Tk
from login_window import LoginWindow


def main():
    root = Tk()
    LoginWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()