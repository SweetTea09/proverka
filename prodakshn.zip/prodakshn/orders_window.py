import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from db import get_connection
from order_form import OrderForm


class OrdersWindow:

    def __init__(self, parent, user):

        self.user = user

        self.window = tk.Toplevel(parent)

        self.window.title("Заказы")
        self.window.geometry("1200x700")
        self.window.configure(bg="white")

        try:
            self.window.iconbitmap("Icon.ico")
        except:
            pass

        top_frame = tk.Frame(
            self.window,
            bg="#7FFF00"
        )

        top_frame.pack(
            fill="x"
        )

        if self.user[0] == "Администратор":

            tk.Button(
                top_frame,
                text="Добавить заказ",
                bg="#00FA9A",
                command=self.add_order
            ).pack(
                side="left",
                padx=10,
                pady=10
            )

        self.tree = ttk.Treeview(
            self.window,
            columns=(
                "id",
                "article",
                "order_date",
                "delivery_date",
                "pickup",
                "client",
                "code",
                "status"
            ),
            show="headings"
        )

        self.tree.heading(
            "id",
            text="Номер заказа"
        )

        self.tree.heading(
            "article",
            text="Артикул"
        )

        self.tree.heading(
            "order_date",
            text="Дата заказа"
        )

        self.tree.heading(
            "delivery_date",
            text="Дата доставки"
        )

        self.tree.heading(
            "pickup",
            text="Пункт выдачи"
        )

        self.tree.heading(
            "client",
            text="Клиент"
        )

        self.tree.heading(
            "code",
            text="Код"
        )

        self.tree.heading(
            "status",
            text="Статус"
        )

        self.tree.pack(
            fill="both",
            expand=True,
            padx=10,
            pady=10
        )

        self.tree.bind(
            "<Double-1>",
            self.edit_order
        )

        if self.user[0] == "Администратор":

            tk.Button(
                self.window,
                text="Удалить заказ",
                bg="tomato",
                command=self.delete_order
            ).pack(
                pady=10
            )

        self.load_orders()

    def load_orders(self):

        for row in self.tree.get_children():
            self.tree.delete(row)

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT *
            FROM "Zakaz"
            ORDER BY "Номер заказа"
        """)

        orders = cur.fetchall()

        cur.close()
        conn.close()

        for order in orders:

            self.tree.insert(
                "",
                "end",
                values=order
            )

    def add_order(self):

        OrderForm(
            self.window,
            self.load_orders
        )

    def edit_order(self, event):

        if self.user[0] != "Администратор":
            return

        selected = self.tree.selection()

        if not selected:
            return

        values = self.tree.item(
            selected[0]
        )["values"]

        OrderForm(
            self.window,
            self.load_orders,
            values
        )

    def delete_order(self):

        selected = self.tree.selection()

        if not selected:

            messagebox.showwarning(
                "Внимание",
                "Выберите заказ"
            )

            return

        order_id = self.tree.item(
            selected[0]
        )["values"][0]

        result = messagebox.askyesno(
            "Подтверждение",
            "Удалить заказ?"
        )

        if not result:
            return

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            DELETE FROM "Zakaz"
            WHERE "Номер заказа"=%s
        """, (order_id,))

        conn.commit()

        cur.close()
        conn.close()

        self.load_orders()