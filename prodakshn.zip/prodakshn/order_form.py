import tkinter as tk

from tkinter import ttk
from tkinter import messagebox

from db import get_connection


class OrderForm:

    def __init__(
            self,
            parent,
            refresh_callback,
            order=None
    ):

        self.refresh_callback = refresh_callback
        self.order = order

        self.window = tk.Toplevel(parent)

        self.window.title("Заказ")
        self.window.geometry("500x500")
        self.window.configure(bg="white")

        try:
            self.window.iconbitmap("Icon.ico")
        except:
            pass

        self.create_widgets()

        if order:
            self.load_order()

    def create_widgets(self):

        frame = tk.Frame(
            self.window,
            bg="white"
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=20
        )

        tk.Label(
            frame,
            text="Артикул товара",
            bg="white"
        ).pack(anchor="w")

        self.article_entry = tk.Entry(frame)

        self.article_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="Дата заказа",
            bg="white"
        ).pack(anchor="w")

        self.order_date_entry = tk.Entry(frame)

        self.order_date_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="Дата доставки",
            bg="white"
        ).pack(anchor="w")

        self.delivery_date_entry = tk.Entry(frame)

        self.delivery_date_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="Пункт выдачи",
            bg="white"
        ).pack(anchor="w")

        self.pickup_entry = tk.Entry(frame)

        self.pickup_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="ФИО клиента",
            bg="white"
        ).pack(anchor="w")

        self.client_entry = tk.Entry(frame)

        self.client_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="Код получения",
            bg="white"
        ).pack(anchor="w")

        self.code_entry = tk.Entry(frame)

        self.code_entry.pack(
            fill="x",
            pady=5
        )

        tk.Label(
            frame,
            text="Статус заказа",
            bg="white"
        ).pack(anchor="w")

        self.status_box = ttk.Combobox(
            frame,
            state="readonly",
            values=[
                "Новый",
                "В обработке",
                "Готов к выдаче",
                "Получен"
            ]
        )

        self.status_box.pack(
            fill="x",
            pady=5
        )

        tk.Button(
            frame,
            text="Сохранить",
            bg="#00FA9A",
            command=self.save_order
        ).pack(
            fill="x",
            pady=20
        )

    def load_order(self):

        self.article_entry.insert(
            0,
            self.order[1]
        )

        self.order_date_entry.insert(
            0,
            self.order[2]
        )

        self.delivery_date_entry.insert(
            0,
            self.order[3]
        )

        self.pickup_entry.insert(
            0,
            self.order[4]
        )

        self.client_entry.insert(
            0,
            self.order[5]
        )

        self.code_entry.insert(
            0,
            self.order[6]
        )

        self.status_box.set(
            self.order[7]
        )

    def save_order(self):

        article = self.article_entry.get()

        if article == "":

            messagebox.showerror(
                "Ошибка",
                "Введите артикул"
            )

            return

        conn = get_connection()
        cur = conn.cursor()

        if self.order:

            cur.execute("""
                UPDATE "Zakaz"
                SET
                "Артикул заказа"=%s,
                "Дата заказа"=%s,
                "Дата доставки"=%s,
                "Адрес пункта выдачи"=%s,
                "ФИО авторизированного клиента"=%s,
                "Код для получения"=%s,
                "Статус заказа"=%s
                WHERE "Номер заказа"=%s
            """, (
                article,
                self.order_date_entry.get(),
                self.delivery_date_entry.get(),
                self.pickup_entry.get(),
                self.client_entry.get(),
                self.code_entry.get(),
                self.status_box.get(),
                self.order[0]
            ))

        else:

            cur.execute("""
                SELECT COALESCE(
                    MAX("Номер заказа"),0
                ) + 1
                FROM "Zakaz"
            """)

            new_id = cur.fetchone()[0]

            cur.execute("""
                INSERT INTO "Zakaz"
                (
                    "Номер заказа",
                    "Артикул заказа",
                    "Дата заказа",
                    "Дата доставки",
                    "Адрес пункта выдачи",
                    "ФИО авторизированного клиента",
                    "Код для получения",
                    "Статус заказа"
                )
                VALUES
                (%s,%s,%s,%s,%s,%s,%s,%s)
            """, (
                new_id,
                article,
                self.order_date_entry.get(),
                self.delivery_date_entry.get(),
                self.pickup_entry.get(),
                self.client_entry.get(),
                self.code_entry.get(),
                self.status_box.get()
            ))

        conn.commit()

        cur.close()
        conn.close()

        self.refresh_callback()

        self.window.destroy()

        messagebox.showinfo(
            "Успешно",
            "Заказ сохранён"
        )

'''Чтобы окно заказов реально открывалось из списка товаров, в products_window.py нужно заменить метод:
def open_orders(self): на:
from orders_window import OrdersWindow
def open_orders(self):
    OrdersWindow(
        self.window,
        self.user
    )

И для открытия формы товара заменить:
def add_product(self):'''