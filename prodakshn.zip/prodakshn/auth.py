from db import get_connection


def login_user(login, password):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM "User"
        WHERE "Логин"=%s
        AND "Пароль"=%s
    """, (login, password))

    user = cursor.fetchone()

    cursor.close()
    conn.close()

    return user