import tkinter as tk
from tkinter import messagebox
from PIL import Image
from PIL import ImageTk

from auth import login_user
from products_window import ProductsWindow


class LoginWindow:

    def __init__(self, root):

        self.root = root

        self.root.title("Авторизация")
        self.root.geometry("700x500")
        self.root.configure(bg="white")

        try:
            self.root.iconbitmap("Icon.ico")
        except:
            pass

        self.logo_label = tk.Label(
            root,
            bg="white"
        )
        self.logo_label.pack(pady=20)

        try:
            image = Image.open("logo.png")
            image = image.resize((250, 150))
            self.logo = ImageTk.PhotoImage(image)

            self.logo_label.config(image=self.logo)

        except:
            pass

        title = tk.Label(
            root,
            text="Вход в систему",
            font=("Times New Roman", 18, "bold"),
            bg="white"
        )
        title.pack(pady=10)

        tk.Label(
            root,
            text="Логин",
            font=("Times New Roman", 12),
            bg="white"
        ).pack()

        self.login_entry = tk.Entry(
            root,
            width=30,
            font=("Times New Roman", 12)
        )
        self.login_entry.pack(pady=5)

        tk.Label(
            root,
            text="Пароль",
            font=("Times New Roman", 12),
            bg="white"
        ).pack()

        self.password_entry = tk.Entry(
            root,
            show="*",
            width=30,
            font=("Times New Roman", 12)
        )
        self.password_entry.pack(pady=5)

        login_button = tk.Button(
            root,
            text="Войти",
            bg="#00FA9A",
            width=20,
            command=self.login
        )
        login_button.pack(pady=10)

        guest_button = tk.Button(
            root,
            text="Войти как гость",
            bg="#7FFF00",
            width=20,
            command=self.guest_login
        )
        guest_button.pack()

    def login(self):

        login = self.login_entry.get()
        password = self.password_entry.get()

        if login == "" or password == "":
            messagebox.showerror(
                "Ошибка",
                "Введите логин и пароль"
            )
            return

        user = login_user(login, password)

        if user is None:

            messagebox.showerror(
                "Ошибка",
                "Неверный логин или пароль"
            )
            return

        self.root.withdraw()

        ProductsWindow(
            self.root,
            user
        )

    def guest_login(self):
        self.root.withdraw()

        ProductsWindow(
            self.root,
            None
        )

#pip install psycopg2
#pip install pillow