import os
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

from PIL import Image
from PIL import ImageTk

from db import get_connection


class ProductsWindow:

    def __init__(self, parent, user):

        self.parent = parent
        self.user = user

        self.window = tk.Toplevel(parent)

        self.window.title("Список товаров")
        self.window.geometry("1400x800")
        self.window.configure(bg="white")

        try:
            self.window.iconbitmap("Icon.ico")
        except:
            pass

        self.create_top_panel()
        self.create_filters()
        self.create_products_area()

        self.load_suppliers()
        self.load_products()

    def create_top_panel(self):

        top_frame = tk.Frame(
            self.window,
            bg="#7FFF00",
            height=60
        )

        top_frame.pack(fill="x")

        fio = "Гость"

        if self.user:
            fio = self.user[1]

        tk.Label(
            top_frame,
            text=fio,
            bg="#7FFF00",
            font=("Times New Roman", 12, "bold")
        ).pack(
            side="right",
            padx=20
        )

        tk.Button(
            top_frame,
            text="Выход",
            bg="#00FA9A",
            command=self.logout
        ).pack(
            side="right",
            padx=10
        )

        if self.user:

            role = self.user[0]

            if role in ["Менеджер", "Администратор"]:

                tk.Button(
                    top_frame,
                    text="Заказы",
                    bg="#00FA9A",
                    command=self.open_orders
                ).pack(
                    side="left",
                    padx=10
                )

            if role == "Администратор":

                tk.Button(
                    top_frame,
                    text="Добавить товар",
                    bg="#00FA9A",
                    command=self.add_product
                ).pack(
                    side="left",
                    padx=10
                )

    def create_filters(self):

        frame = tk.Frame(
            self.window,
            bg="white"
        )

        frame.pack(
            fill="x",
            padx=10,
            pady=10
        )

        tk.Label(
            frame,
            text="Поиск:",
            bg="white",
            font=("Times New Roman", 11)
        ).pack(side="left")

        self.search_var = tk.StringVar()

        search_entry = tk.Entry(
            frame,
            textvariable=self.search_var,
            width=30
        )

        search_entry.pack(
            side="left",
            padx=5
        )

        self.search_var.trace(
            "w",
            lambda *args: self.load_products()
        )

        tk.Label(
            frame,
            text="Поставщик:",
            bg="white"
        ).pack(
            side="left",
            padx=10
        )

        self.supplier_box = ttk.Combobox(
            frame,
            state="readonly",
            width=25
        )

        self.supplier_box.pack(side="left")

        self.supplier_box.bind(
            "<<ComboboxSelected>>",
            lambda e: self.load_products()
        )

        tk.Label(
            frame,
            text="Сортировка:",
            bg="white"
        ).pack(
            side="left",
            padx=10
        )

        self.sort_box = ttk.Combobox(
            frame,
            values=[
                "Без сортировки",
                "Количество ↑",
                "Количество ↓"
            ],
            state="readonly",
            width=20
        )

        self.sort_box.current(0)

        self.sort_box.pack(side="left")

        self.sort_box.bind(
            "<<ComboboxSelected>>",
            lambda e: self.load_products()
        )

    def create_products_area(self):

        self.canvas = tk.Canvas(
            self.window,
            bg="white"
        )

        scrollbar = ttk.Scrollbar(
            self.window,
            orient="vertical",
            command=self.canvas.yview
        )

        self.scroll_frame = tk.Frame(
            self.canvas,
            bg="white"
        )

        self.scroll_frame.bind(
            "<Configure>",
            lambda e:
            self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.create_window(
            (0, 0),
            window=self.scroll_frame,
            anchor="nw"
        )

        self.canvas.configure(
            yscrollcommand=scrollbar.set
        )

        self.canvas.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

    def load_suppliers(self):

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT DISTINCT "Поставщик"
            FROM "Tovar"
            ORDER BY "Поставщик"
        """)

        suppliers = ["Все поставщики"]

        for item in cur.fetchall():
            suppliers.append(item[0])

        self.supplier_box["values"] = suppliers
        self.supplier_box.current(0)

        cur.close()
        conn.close()

    def load_products(self):

        for widget in self.scroll_frame.winfo_children():
            widget.destroy()

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT *
            FROM "Tovar"
        """)

        products = cur.fetchall()

        cur.close()
        conn.close()

        search_text = self.search_var.get().lower()

        supplier = self.supplier_box.get()

        filtered = []

        for product in products:

            text = " ".join(
                map(str, product)
            ).lower()

            if search_text not in text:
                continue

            if supplier != "Все поставщики":

                if product[4] != supplier:
                    continue

            filtered.append(product)

        sort_type = self.sort_box.get()

        if sort_type == "Количество ↑":
            filtered.sort(key=lambda x: x[8])

        elif sort_type == "Количество ↓":
            filtered.sort(
                key=lambda x: x[8],
                reverse=True
            )

        for product in filtered:
            self.create_card(product)

    def create_card(self, product):

        discount = float(product[7])

        stock = int(product[8])

        bg_color = "white"

        if discount > 15:
            bg_color = "#2E8B57"

        if stock == 0:
            bg_color = "#87CEEB"

        card = tk.Frame(
            self.scroll_frame,
            bg=bg_color,
            relief="solid",
            bd=1
        )

        card.pack(
            fill="x",
            padx=10,
            pady=5
        )

        image_path = product[10]

        if not image_path:
            image_path = "picture.png"

        if not os.path.exists(image_path):
            image_path = "picture.png"

        try:

            img = Image.open(image_path)
            img.thumbnail((150, 120))

            photo = ImageTk.PhotoImage(img)

            image_label = tk.Label(
                card,
                image=photo,
                bg=bg_color
            )

            image_label.image = photo

            image_label.pack(
                side="left",
                padx=10,
                pady=10
            )

        except:

            pass

        info = tk.Frame(
            card,
            bg=bg_color
        )

        info.pack(
            side="left",
            fill="both",
            expand=True
        )

        tk.Label(
            info,
            text=f"{product[1]}",
            font=("Times New Roman", 14, "bold"),
            bg=bg_color
        ).pack(anchor="w")

        tk.Label(
            info,
            text=f"Категория: {product[6]}",
            bg=bg_color
        ).pack(anchor="w")

        tk.Label(
            info,
            text=f"Производитель: {product[5]}",
            bg=bg_color
        ).pack(anchor="w")

        tk.Label(
            info,
            text=f"Поставщик: {product[4]}",
            bg=bg_color
        ).pack(anchor="w")

        tk.Label(
            info,
            text=f"Количество: {product[8]}",
            bg=bg_color
        ).pack(anchor="w")

        price_frame = tk.Frame(
            info,
            bg=bg_color
        )

        price_frame.pack(anchor="w")

        price = float(product[3])

        if discount > 0:

            final_price = price - (
                price * discount / 100
            )

            tk.Label(
                price_frame,
                text=f"{price:.2f} ₽",
                fg="red",
                bg=bg_color,
                font=(
                    "Times New Roman",
                    11,
                    "overstrike"
                )
            ).pack(side="left")

            tk.Label(
                price_frame,
                text=f"   {final_price:.2f} ₽",
                bg=bg_color
            ).pack(side="left")

        else:

            tk.Label(
                price_frame,
                text=f"{price:.2f} ₽",
                bg=bg_color
            ).pack(side="left")

        tk.Label(
            card,
            text=f"{discount}%",
            font=("Times New Roman", 18, "bold"),
            bg=bg_color
        ).pack(
            side="right",
            padx=20
        )

        if self.user:

            role = self.user[0]

            if role == "Администратор":

                tk.Button(
                    card,
                    text="Редактировать",
                    bg="#00FA9A",
                    command=lambda p=product:
                    self.edit_product(p)
                ).pack(
                    side="right",
                    padx=10
                )

    def edit_product(self, product):

        messagebox.showinfo(
            "Информация",
            f"Редактирование товара {product[1]}"
        )

    def add_product(self):

        messagebox.showinfo(
            "Информация",
            "Открыть форму добавления товара"
        )

    def open_orders(self):

        messagebox.showinfo(
            "Информация",
            "Открыть окно заказов"
        )

    def logout(self):

        self.window.destroy()
        self.parent.deiconify()