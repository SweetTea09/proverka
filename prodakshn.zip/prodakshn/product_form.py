import os
import shutil
import tkinter as tk

from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox

from PIL import Image
from PIL import ImageTk

from db import get_connection


class ProductForm:

    def __init__(self, parent, refresh_callback, product=None):

        self.refresh_callback = refresh_callback
        self.product = product

        self.window = tk.Toplevel(parent)

        self.window.title("Товар")
        self.window.geometry("700x750")
        self.window.configure(bg="white")

        try:
            self.window.iconbitmap("Icon.ico")
        except:
            pass

        self.image_path = ""

        self.create_widgets()

        if product:
            self.load_product()

    def create_widgets(self):

        frame = tk.Frame(
            self.window,
            bg="white"
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=20,
            pady=20
        )

        row = 0

        if self.product:

            tk.Label(
                frame,
                text="Артикул",
                bg="white"
            ).grid(row=row, column=0, sticky="w")

            self.article_entry = tk.Entry(
                frame,
                state="readonly"
            )

            self.article_entry.grid(
                row=row,
                column=1,
                sticky="ew"
            )

            row += 1

        tk.Label(
            frame,
            text="Наименование",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.name_entry = tk.Entry(frame)

        self.name_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Единица измерения",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.unit_entry = tk.Entry(frame)

        self.unit_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Цена",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.price_entry = tk.Entry(frame)

        self.price_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Поставщик",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.supplier_entry = tk.Entry(frame)

        self.supplier_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Производитель",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.manufacturer_entry = tk.Entry(frame)

        self.manufacturer_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Категория",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.category_entry = tk.Entry(frame)

        self.category_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Скидка (%)",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.discount_entry = tk.Entry(frame)

        self.discount_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Количество",
            bg="white"
        ).grid(row=row, column=0, sticky="w")

        self.stock_entry = tk.Entry(frame)

        self.stock_entry.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Label(
            frame,
            text="Описание",
            bg="white"
        ).grid(row=row, column=0, sticky="nw")

        self.description_text = tk.Text(
            frame,
            height=6
        )

        self.description_text.grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        self.image_label = tk.Label(
            frame,
            bg="white"
        )

        self.image_label.grid(
            row=row,
            column=1,
            pady=10
        )

        row += 1

        tk.Button(
            frame,
            text="Выбрать изображение",
            bg="#00FA9A",
            command=self.choose_image
        ).grid(
            row=row,
            column=1,
            sticky="ew"
        )

        row += 1

        tk.Button(
            frame,
            text="Сохранить",
            bg="#00FA9A",
            command=self.save_product
        ).grid(
            row=row,
            column=1,
            sticky="ew",
            pady=15
        )

    def choose_image(self):

        filename = filedialog.askopenfilename(
            filetypes=[
                ("Images", "*.jpg *.jpeg *.png")
            ]
        )

        if not filename:
            return

        if not os.path.exists("images"):
            os.makedirs("images")

        image_name = os.path.basename(filename)

        new_path = os.path.join(
            "images",
            image_name
        )

        shutil.copy(
            filename,
            new_path
        )

        self.image_path = new_path

        self.show_image(new_path)

    def show_image(self, path):

        try:

            image = Image.open(path)

            image.thumbnail((300, 200))

            photo = ImageTk.PhotoImage(image)

            self.image_label.configure(
                image=photo
            )

            self.image_label.image = photo

        except:
            pass

    def load_product(self):

        self.article_entry.config(state="normal")
        self.article_entry.insert(0, self.product[0])
        self.article_entry.config(state="readonly")

        self.name_entry.insert(0, self.product[1])
        self.unit_entry.insert(0, self.product[2])
        self.price_entry.insert(0, self.product[3])
        self.supplier_entry.insert(0, self.product[4])
        self.manufacturer_entry.insert(0, self.product[5])
        self.category_entry.insert(0, self.product[6])
        self.discount_entry.insert(0, self.product[7])
        self.stock_entry.insert(0, self.product[8])

        self.description_text.insert(
            "1.0",
            self.product[9]
        )

        self.image_path = self.product[10]

        if self.image_path:
            self.show_image(self.image_path)

    def save_product(self):

        try:

            price = float(
                self.price_entry.get()
            )

            stock = int(
                self.stock_entry.get()
            )

            discount = float(
                self.discount_entry.get()
            )

            if price < 0:
                raise ValueError

            if stock < 0:
                raise ValueError

        except:

            messagebox.showerror(
                "Ошибка",
                "Некорректная цена, скидка или количество."
            )

            return

        conn = get_connection()
        cur = conn.cursor()

        if self.product:

            cur.execute("""
                UPDATE "Tovar"
                SET
                "Наименование товара"=%s,
                "Единица измерения"=%s,
                "Цена"=%s,
                "Поставщик"=%s,
                "Производитель"=%s,
                "Категория товара"=%s,
                "Действующая скидка"=%s,
                "Кол-во на складе"=%s,
                "Описание товара"=%s,
                "Фото"=%s
                WHERE "Артикул"=%s
            """, (
                self.name_entry.get(),
                self.unit_entry.get(),
                price,
                self.supplier_entry.get(),
                self.manufacturer_entry.get(),
                self.category_entry.get(),
                discount,
                stock,
                self.description_text.get(
                    "1.0",
                    "end"
                ).strip(),
                self.image_path,
                self.product[0]
            ))

        else:

            cur.execute("""
                SELECT COALESCE(
                    MAX("Артикул"),0
                ) + 1
                FROM "Tovar"
            """)

            new_id = cur.fetchone()[0]

            cur.execute("""
                INSERT INTO "Tovar"
                (
                    "Артикул",
                    "Наименование товара",
                    "Единица измерения",
                    "Цена",
                    "Поставщик",
                    "Производитель",
                    "Категория товара",
                    "Действующая скидка",
                    "Кол-во на складе",
                    "Описание товара",
                    "Фото"
                )
                VALUES
                (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """, (
                new_id,
                self.name_entry.get(),
                self.unit_entry.get(),
                price,
                self.supplier_entry.get(),
                self.manufacturer_entry.get(),
                self.category_entry.get(),
                discount,
                stock,
                self.description_text.get(
                    "1.0",
                    "end"
                ).strip(),
                self.image_path
            ))

        conn.commit()

        cur.close()
        conn.close()

        messagebox.showinfo(
            "Успешно",
            "Товар сохранён."
        )

        self.refresh_callback()

        self.window.destroy()

#Теперь в products_window.py нужно заменить заглушки:
#def add_product(self): и def edit_product(self, product):