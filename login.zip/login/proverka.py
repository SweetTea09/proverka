import tkinter as tk
from tkinter import messagebox
import psycopg2


# ==========================
# PostgreSQL
# ==========================

def get_connection():
    return psycopg2.connect(user="postgres",port="5432",host="46.8.225.46",database="demo_molodova",password="Buhjvfybz123!")


# ==========================
# Авторизация
# ==========================

def login():

    login_text = login_entry.get()
    password_text = password_entry.get()

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT *
        FROM "user"
        WHERE "login"=%s
        AND "password"=%s
    """, (
        login_text,
        password_text
    ))

    user = cur.fetchone()

    cur.close()
    conn.close()

    if user is None:

        messagebox.showerror(
            "Ошибка",
            "Неверный логин или пароль"
        )

        return

    open_products(user)


def guest_login():
    open_products(None)


# ==========================
# Окно товаров
# ==========================

def open_products(user):

    login_frame.pack_forget()

    products_frame.pack(
        fill="both",
        expand=True
    )

    if user:

        fio_label.config(
            text=f"{user[1]} ({user[0]})"
        )

        role = user[0]

        if role == "Администратор":

            add_product_btn.pack(
                side="left",
                padx=5
            )

            orders_btn.pack(
                side="left",
                padx=5
            )

            add_order_btn.pack(
                side="left",
                padx=5
            )

        elif role == "Менеджер":

            orders_btn.pack(
                side="left",
                padx=5
            )

    else:

        fio_label.config(
            text="Гость"
        )


# ==========================
# Пустые окна
# ==========================

def open_product_form():

    win = tk.Toplevel(root)

    win.title("Форма товара")
    win.geometry("500x300")

    tk.Label(
        win,
        text="Форма добавления/редактирования товара",
        font=("Times New Roman", 14)
    ).pack(pady=100)


def open_orders():

    win = tk.Toplevel(root)

    win.title("Список заказов")
    win.geometry("500x300")

    tk.Label(
        win,
        text="Окно списка заказов",
        font=("Times New Roman", 14)
    ).pack(pady=100)


def open_order_form():

    win = tk.Toplevel(root)

    win.title("Форма заказа")
    win.geometry("500x300")

    tk.Label(
        win,
        text="Форма добавления/редактирования заказа",
        font=("Times New Roman", 14)
    ).pack(pady=100)


# ==========================
# Выход
# ==========================

def logout():

    products_frame.pack_forget()

    add_product_btn.pack_forget()
    orders_btn.pack_forget()
    add_order_btn.pack_forget()

    login_frame.pack(
        fill="both",
        expand=True
    )


# ==========================
# Главное окно
# ==========================

root = tk.Tk()

root.title("Магазин обуви")
root.geometry("1000x700")

try:
    root.iconbitmap("Icon.ico")
except:
    pass


# ==========================
# Авторизация
# ==========================

login_frame = tk.Frame(
    root,
    bg="white"
)

login_frame.pack(
    fill="both",
    expand=True
)

tk.Label(
    login_frame,
    text="Авторизация",
    font=("Times New Roman", 20, "bold"),
    bg="white"
).pack(pady=30)

tk.Label(
    login_frame,
    text="Логин",
    bg="white"
).pack()

login_entry = tk.Entry(
    login_frame,
    width=30
)

login_entry.pack()

tk.Label(
    login_frame,
    text="Пароль",
    bg="white"
).pack()

password_entry = tk.Entry(
    login_frame,
    width=30,
    show="*"
)

password_entry.pack()

tk.Button(
    login_frame,
    text="Войти",
    bg="#00FA9A",
    width=20,
    command=login
).pack(pady=10)

tk.Button(
    login_frame,
    text="Войти как гость",
    bg="#7FFF00",
    width=20,
    command=guest_login
).pack()


# ==========================
# Окно товаров
# ==========================

products_frame = tk.Frame(
    root,
    bg="white"
)

top_frame = tk.Frame(
    products_frame,
    bg="#7FFF00"
)

top_frame.pack(
    fill="x"
)

fio_label = tk.Label(
    top_frame,
    text="",
    bg="#7FFF00",
    font=("Times New Roman", 12, "bold")
)

fio_label.pack(
    side="right",
    padx=20,
    pady=10
)

tk.Button(
    top_frame,
    text="Выход",
    bg="#00FA9A",
    command=logout
).pack(
    side="right",
    padx=10,
    pady=10
)

add_product_btn = tk.Button(
    top_frame,
    text="Форма товара",
    bg="#00FA9A",
    command=open_product_form
)

orders_btn = tk.Button(
    top_frame,
    text="Заказы",
    bg="#00FA9A",
    command=open_orders
)

add_order_btn = tk.Button(
    top_frame,
    text="Форма заказа",
    bg="#00FA9A",
    command=open_order_form
)

content_frame = tk.Frame(
    products_frame,
    bg="white"
)

content_frame.pack(
    fill="both",
    expand=True
)

tk.Label(
    content_frame,
    text="Окно товаров",
    font=("Times New Roman", 20, "bold"),
    bg="white"
).pack(pady=150)

root.mainloop()